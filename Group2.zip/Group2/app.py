# We simplified all the aliases for the simplicity and to avoid line breaks. For example, not "hotels" or "hotels AS htl" but "hotel h"

from flask import Flask, render_template, request, redirect, url_for
import os
import sqlite3

app = Flask(__name__)
DATABASE = "last_resort.db"

# Set up the connection
def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# The function that is used in the future
def get_hotels(conn):
    return conn.execute("SELECT * FROM hotel_complex ORDER BY name").fetchall()

# Show splash
@app.route("/", methods=["GET"])
def splash():
    return render_template("splash.html")

# This block defines the main page
@app.route("/home", methods=["GET"])
def home():
    conn = get_db_connection()
    hotels = get_hotels(conn)

    hotel_cards = conn.execute("""
        SELECT h.hotelComplexId, h.name, h.address,
               COUNT(DISTINCT b.buildingId) AS buildingCount,
               COUNT(DISTINCT r.roomId) AS roomCount
        FROM hotel_complex h
        LEFT JOIN building b ON b.hotelComplexId = h.hotelComplexId
        LEFT JOIN wing w ON w.buildingId = b.buildingId
        LEFT JOIN room r ON r.wingId = w.wingId
        GROUP BY h.hotelComplexId
        ORDER BY h.name
    """).fetchall()

    active_stays = conn.execute("""
        SELECT s.stayId, s.checkinTime, s.checkoutTime, s.numberOfGuest,
               c.firstName, c.lastName,
               r.specialRequest, r.status
        FROM stay s
        JOIN reservation r ON r.reservationId = s.reservationId
        JOIN customer c ON c.customerId = r.customerId
        ORDER BY s.checkinTime
    """).fetchall()

    reservations = conn.execute("""
        SELECT r.reservationId, r.reservationDate, r.specialRequest, r.status,
               c.firstName, c.lastName
        FROM reservation r
        JOIN customer c ON c.customerId = r.customerId
        ORDER BY r.reservationDate DESC
    """).fetchall()

    rooms = conn.execute("""
        SELECT r.roomId, r.number, r.floor, r.type, r.maxOccupancy,
               r.baseRate, r.status,
               w.name AS wingName,
               b.name AS buildingName,
               h.name AS hotelName
        FROM room r
        JOIN wing w ON w.wingId = r.wingId
        JOIN building b ON b.buildingId = w.buildingId
        JOIN hotel_complex h ON h.hotelComplexId = b.hotelComplexId
        ORDER BY h.name, b.name, r.floor, r.number
    """).fetchall()

    messages = conn.execute("""
        SELECT messageId, senderName, messageContext, timeRecorded, status, confidential
        FROM message
        ORDER BY timeRecorded DESC
        LIMIT 5
    """).fetchall()

    stats = {
        "hotels": conn.execute("SELECT COUNT(*) FROM hotel_complex").fetchone()[0],
        "rooms": conn.execute("SELECT COUNT(*) FROM room").fetchone()[0],
        "guests": conn.execute("SELECT COUNT(*) FROM customer").fetchone()[0],
        "active_stays": len(active_stays),
        "available_rooms": conn.execute(
            "SELECT COUNT(*) FROM room WHERE status = 'Available'"
        ).fetchone()[0],
    }

    conn.close()
    return render_template(
        "index.html",
        hotels=hotels,
        hotel_cards=hotel_cards,
        active_stays=active_stays,
        reservations=reservations,
        rooms=rooms,
        messages=messages,
        stats=stats,
    )

# This is for hotels page
@app.route("/hotels", methods=["GET"])
def hotels():
    conn = get_db_connection()
    hotels = get_hotels(conn)

    hotel_cards = conn.execute("""
        SELECT h.hotelComplexId, h.name, h.address,
               COUNT(DISTINCT b.buildingId) AS buildingCount,
               COUNT(DISTINCT w.wingId)     AS wingCount,
               COUNT(DISTINCT r.roomId)     AS roomCount
        FROM hotel_complex h
        LEFT JOIN building b ON b.hotelComplexId = h.hotelComplexId
        LEFT JOIN wing w     ON w.buildingId = b.buildingId
        LEFT JOIN room r     ON r.wingId = w.wingId
        GROUP BY h.hotelComplexId
        ORDER BY h.name
    """).fetchall()

    building_rows = conn.execute("""
        SELECT b.hotelComplexId, b.name
        FROM building b
        ORDER BY b.hotelComplexId, b.name
    """).fetchall()
    buildings_by_hotel = {}
    for row in building_rows:
        buildings_by_hotel.setdefault(row["hotelComplexId"], []).append(row["name"])

    conn.close()
    return render_template(
        "hotels.html",
        hotels=hotels,
        hotel_cards=hotel_cards,
        buildings_by_hotel=buildings_by_hotel,
    )

# This is for hotel page
@app.route("/hotel", methods=["GET"])
def hotel():
    hotel_id = request.args.get("hotelId", type=int)
    conn = get_db_connection()
    hotels = get_hotels(conn)
    selected = conn.execute(
        "SELECT * FROM hotel_complex WHERE hotelComplexId = ?", (hotel_id,)
    ).fetchone()

    rooms = conn.execute("""
        SELECT r.*, w.name AS wingName, b.name AS buildingName
        FROM room r
        JOIN wing w ON w.wingId = r.wingId
        JOIN building b ON b.buildingId = w.buildingId
        WHERE b.hotelComplexId = ?
        ORDER BY b.name, w.name, r.floor, r.number
    """, (hotel_id,)).fetchall()

    conn.close()
    return render_template(
        "hotel.html",
        hotels=hotels,
        selected=selected,
        rooms=rooms,
    )

# This is for room page
@app.route("/room", methods=["GET"])
def room_detail():
    room_id = request.args.get("roomId", type=int)
    conn = get_db_connection()
    hotels = get_hotels(conn)

    room = conn.execute("""
        SELECT r.*, w.name AS wingName, w.proximityFeatures,
               b.name AS buildingName, h.name AS hotelName,
               h.hotelComplexId
        FROM room r
        JOIN wing w ON w.wingId = r.wingId
        JOIN building b ON b.buildingId = w.buildingId
        JOIN hotel_complex h ON h.hotelComplexId = b.hotelComplexId
        WHERE r.roomId = ?
    """, (room_id,)).fetchone()

    features = conn.execute("""
        SELECT f.name, f.value, rfa.quantity
        FROM room_feature_assignment rfa
        JOIN feature f ON f.featureId = rfa.featureId
        WHERE rfa.roomId = ?
    """, (room_id,)).fetchall()

    conn.close()
    return render_template(
        "room.html",
        hotels=hotels,
        room=room,
        features=features,
    )

# This is the first search button
@app.route("/search", methods=["GET", "POST"])
def search():
    if request.method == "POST":
        term = request.form.get("search", "").strip()
    else:
        term = request.args.get("q", "").strip()

    if not term:
        return render_template(
            "search.html",
            hotels=_hotels(),
            searchTerm="",
            resultType="empty",
        )

    if ":" in term:
        prefix, arg = term.split(":", 1)
        prefix, arg = prefix.strip().lower(), arg.strip()
        handler = _PREFIX_COMMANDS.get(prefix)
        if handler:
            return handler(arg, term)

    keyword_handler = _KEYWORD_COMMANDS.get(term.lower())
    if keyword_handler:
        return keyword_handler(term)

    return _fuzzy_search(term)

# This is for search help page
@app.route("/search/help", methods=["GET"])
def search_help():
    return render_template("search_help.html", hotels=_hotels())

# Helpers
def _hotels():
    conn = get_db_connection()
    try:
        return get_hotels(conn)
    finally:
        conn.close()

# For rendering
def _render(result_type, search_term, **extra):
    return render_template(
        "search.html",
        hotels=_hotels(),
        searchTerm=search_term,
        resultType=result_type,
        **extra,
    )


# This is for fuzzy search function
def _fuzzy_search(term):
    conn = get_db_connection()
    rooms = conn.execute("""
        SELECT r.*, w.name AS wingName, b.name AS buildingName, h.name AS hotelName
        FROM room r
        JOIN wing w           ON w.wingId = r.wingId
        JOIN building b       ON b.buildingId = w.buildingId
        JOIN hotel_complex h  ON h.hotelComplexId = b.hotelComplexId
        WHERE CAST(r.number AS TEXT) LIKE ?
           OR lower(r.type) LIKE lower(?)
           OR lower(r.status) LIKE lower(?)
           OR lower(w.name) LIKE lower(?)
           OR lower(b.name) LIKE lower(?)
           OR lower(h.name) LIKE lower(?)
        ORDER BY h.name, b.name, r.number
    """, tuple(f"%{term}%" for _ in range(6))).fetchall()
    conn.close()
    return _render("rooms", term,
                   rooms=rooms,
                   subtitle=f"{len(rooms)} room{'' if len(rooms)==1 else 's'} matched.")

# Below are helper functions for the fuzzy search

def _cmd_status(arg, term):
    conn = get_db_connection()
    rooms = conn.execute("""
        SELECT r.*, w.name AS wingName, b.name AS buildingName, h.name AS hotelName
        FROM room r
        JOIN wing w          ON w.wingId = r.wingId
        JOIN building b      ON b.buildingId = w.buildingId
        JOIN hotel_complex h ON h.hotelComplexId = b.hotelComplexId
        WHERE lower(r.status) = lower(?)
        ORDER BY h.name, b.name, r.number
    """, (arg,)).fetchall()
    conn.close()
    return _render("rooms", term,
                   rooms=rooms,
                   subtitle=f"{len(rooms)} room{'' if len(rooms)==1 else 's'} with status “{arg}”.")

def _cmd_rate(arg, term):
    import re
    m = re.match(r"\s*(>=|<=|>|<|=)?\s*(\d+(?:\.\d+)?)\s*$", arg or "")
    if not m:
        return _render("error", term,
                       errorMessage=f'Could not parse rate filter “{arg}”. Try rate:>200 or rate:<=100.')
    op, val = (m.group(1) or "="), float(m.group(2))
    conn = get_db_connection()
    rooms = conn.execute(f"""
        SELECT r.*, w.name AS wingName, b.name AS buildingName, h.name AS hotelName
        FROM room r
        JOIN wing w          ON w.wingId = r.wingId
        JOIN building b      ON b.buildingId = w.buildingId
        JOIN hotel_complex h ON h.hotelComplexId = b.hotelComplexId
        WHERE r.baseRate {op} ?
        ORDER BY r.baseRate DESC, h.name, b.name, r.number
    """, (val,)).fetchall()
    conn.close()
    return _render("rooms", term,
                   rooms=rooms,
                   subtitle=f"{len(rooms)} room{'' if len(rooms)==1 else 's'} where rate {op} ${val:g}.")

_TIER_BOUNDS = {
    "budget":   ("Budget",   "r.baseRate < 100"),
    "standard": ("Standard", "r.baseRate >= 100 AND r.baseRate <= 200"),
    "premium":  ("Premium",  "r.baseRate > 200"),
}

def _cmd_tier(arg, term):
    key = arg.lower()
    if key not in _TIER_BOUNDS:
        return _render("error", term,
                       errorMessage="Tier must be one of: budget, standard, premium.")
    label, predicate = _TIER_BOUNDS[key]
    conn = get_db_connection()
    rooms = conn.execute(f"""
        SELECT r.*, w.name AS wingName, b.name AS buildingName, h.name AS hotelName,
               CASE
                   WHEN r.baseRate < 100 THEN 'Budget'
                   WHEN r.baseRate <= 200 THEN 'Standard'
                   ELSE 'Premium'
               END AS tier
        FROM room r
        JOIN wing w          ON w.wingId = r.wingId
        JOIN building b      ON b.buildingId = w.buildingId
        JOIN hotel_complex h ON h.hotelComplexId = b.hotelComplexId
        WHERE {predicate}
        ORDER BY r.baseRate, h.name, b.name, r.number
    """).fetchall()
    conn.close()
    return _render("rooms", term,
                   rooms=rooms,
                   subtitle=f"{len(rooms)} room{'' if len(rooms)==1 else 's'} in the {label} tier.")

def _cmd_top_rooms(term):
    conn = get_db_connection()
    rooms = conn.execute("""
        WITH ranked AS (
            SELECT r.roomId, r.number, r.type, r.baseRate, r.status,
                   r.maxOccupancy, r.floor,
                   w.name AS wingName, b.name AS buildingName, h.name AS hotelName,
                   RANK() OVER (PARTITION BY r.wingId ORDER BY r.baseRate DESC) AS rk
            FROM room r
            JOIN wing w          ON w.wingId = r.wingId
            JOIN building b      ON b.buildingId = w.buildingId
            JOIN hotel_complex h ON h.hotelComplexId = b.hotelComplexId
        )
        SELECT * FROM ranked
        WHERE rk = 1
        ORDER BY hotelName, buildingName, wingName
    """).fetchall()
    conn.close()
    return _render("rooms", term,
                   rooms=rooms,
                   subtitle="Highest-rate room in each wing (window function).")

def _cmd_above_avg(term):
    conn = get_db_connection()
    rooms = conn.execute("""
        SELECT r.*, w.name AS wingName, b.name AS buildingName, h.name AS hotelName
        FROM room r
        JOIN wing w          ON w.wingId = r.wingId
        JOIN building b      ON b.buildingId = w.buildingId
        JOIN hotel_complex h ON h.hotelComplexId = b.hotelComplexId
        WHERE r.baseRate > (
            SELECT AVG(r2.baseRate)
            FROM room r2
            WHERE r2.wingId = r.wingId
        )
        ORDER BY h.name, b.name, r.baseRate DESC
    """).fetchall()
    conn.close()
    return _render("rooms", term,
                   rooms=rooms,
                   subtitle="Rooms priced above their own wing's average (correlated subquery).")

def _cmd_orphan_reservations(term):
    conn = get_db_connection()
    rows = conn.execute("""
        SELECT r.reservationId, r.reservationDate, r.specialRequest, r.status,
               c.firstName, c.lastName, c.email
        FROM reservation r
        JOIN customer c ON c.customerId = r.customerId
        LEFT JOIN stay s ON s.reservationId = r.reservationId
        WHERE s.stayId IS NULL
        ORDER BY r.reservationDate DESC
    """).fetchall()
    conn.close()
    return _render("reservations", term,
                   reservations=rows,
                   subtitle=f"{len(rows)} reservation{'' if len(rows)==1 else 's'} with no recorded stay (anti-join).")

def _cmd_top_guests(term):
    conn = get_db_connection()
    rows = conn.execute("""
        SELECT c.customerId, c.firstName, c.lastName, c.email,
               COUNT(DISTINCT s.stayId) AS stayCount,
               SUM(t.finalAmount) AS totalSpend
        FROM customer c
        JOIN reservation r        ON r.customerId = c.customerId
        JOIN stay s               ON s.reservationId = r.reservationId
        JOIN billing_arrangement b ON b.stayId = s.stayId
        JOIN transaction_info t   ON t.billingId = b.billingId
        GROUP BY c.customerId
        HAVING SUM(t.finalAmount) > 0
        ORDER BY totalSpend DESC
    """).fetchall()
    conn.close()
    return _render("guests", term,
                   guests=rows,
                   subtitle=f"{len(rows)} guest{'' if len(rows)==1 else 's'} ranked by total spend (HAVING).")

_PREFIX_COMMANDS = {
    "status": _cmd_status,
    "rate":   _cmd_rate,
    "tier":   _cmd_tier,
}

_KEYWORD_COMMANDS = {
    "top-rooms":           _cmd_top_rooms,
    "above-avg":           _cmd_above_avg,
    "orphan-reservations": _cmd_orphan_reservations,
    "top-guests":          _cmd_top_guests,
}


@app.errorhandler(Exception)
def handle_error(e):
    return render_template("error.html", error=e), 500


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port, debug=True)
