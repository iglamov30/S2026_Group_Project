PRAGMA foreign_keys = ON;

INSERT INTO hotel_complex (hotelComplexId, name, address) VALUES
(1, 'Hotel Star', '100 Park Avenue, New York, NY'),
(2, 'Hotel Dream', '200 Park Avenue, New York, NY'),
(3, 'Hotel Delight', '300 Park Avenue, New York, NY');

INSERT INTO building (buildingId, name, hotelComplexId) VALUES
(1, 'Earth', 1),
(2, 'Venus', 1),
(3, 'Mercury', 2),
(4, 'Mars', 3),
(5, 'Jupiter', 3),
(6, 'Saturn', 2),
(7, 'Uranus', 1),
(8, 'Neptune', 2);

INSERT INTO wing (wingId, name, buildingId, proximityFeatures, handicappedAccess, smokingPolicy) VALUES
(1, 'Wind', 1, 'Close to indoor swimming pool', 1, 'Smoking is prohibited'),
(2, 'Rain', 1, 'Close to parking garage', 1, 'Smoking is prohibited'),
(3, 'Sun', 4, 'Close to outdoor swimming pool and parking garage', 0, 'Smoking is permitted only in specialized areas'),
(4, 'Fog', 5, 'Far from everything', 0, 'Smoking is permitted only in specialized areas'),
(5, 'Rainbow', 2, 'Prime location', 1, 'Smoking is prohibited'),
(6, 'Aurora', 7, 'Close to everything', 1, 'Smoking is prohibited'),
(7, 'Tide', 3, 'Close to the ocean', 0, 'Smoking is permitted only outside'),
(8, 'Eclipse', 8, 'Foresty location', 1, 'Smoking is prohibited'),
(9, 'Twilight', 6, 'Best view of the sky', 1, 'Smoking is permitted on upper floors');

INSERT INTO room (roomId, wingId, number, floor, type, maxOccupancy, baseRate, smokingPolicy, hasToilet, status) VALUES
(1, 1, 11, 1, 'Sleeping', 4, 100.00, 'Not Permitted', 1, 'Available'),
(2, 2, 21, 2, 'Sleeping', 4, 120.00, 'Not Permitted', 1, 'Under Renovation'),
(3, 3, 31, 3, 'Suite', 6, 250.00, 'Not Permitted', 1, 'Available'),
(4, 6, 78, 7, 'Suite', 4, 200.00, 'Permitted', 1, 'Booked'),
(5, 8, 35, 3, 'Single Sleeping', 1, 80.00, 'Permitted', 0, 'Booked'),
(6, 9, 41, 4, 'Sleeping', 4, 100.00, 'Not Permitted', 1, 'Available'),
(7, 4, 18, 1, 'Sleeping', 4, 120.00, 'Not Permitted', 1, 'Under Renovation'),
(8, 5, 30, 3, 'Suite Deluxe', 8, 300.00, 'Not Permitted', 1, 'Available'),
(9, 1, 12, 1, 'Sleeping', 4, 100.00, 'Not Permitted', 1, 'Available'),
(10, 2, 22, 2, 'Sleeping', 4, 120.00, 'Not Permitted', 1, 'Under Renovation'),
(11, 3, 32, 3, 'Suite', 6, 250.00, 'Not Permitted', 1, 'Available'),
(12, 6, 79, 7, 'Suite', 4, 200.00, 'Permitted', 1, 'Booked'),
(13, 4, 36, 3, 'Single Sleeping', 1, 80.00, 'Permitted', 0, 'Booked'),
(14, 9, 42, 4, 'Sleeping', 4, 100.00, 'Not Permitted', 1, 'Available'),
(15, 4, 19, 1, 'Sleeping', 4, 120.00, 'Not Permitted', 1, 'Under Renovation'),
(16, 7, 33, 3, 'Double', 2, 300.00, 'Not Permitted', 1, 'Available');

INSERT INTO feature (featureId, name, value) VALUES
(1, 'Bed Type', 'King Size'),
(2, 'Bed Type', 'Queen Size'),
(3, 'Rollaway Beds', '1 Rollaway Beds');

INSERT INTO room_feature_assignment (roomId, featureId, quantity) VALUES
(1, 1, 2),
(2, 3, 1),
(3, 1, 2),
(6, 1, 2),
(8, 1, 2),
(10, 3, 1),
(11, 3, 2),
(12, 1, 2);

INSERT INTO room_adjacency (roomId1, roomId2, adjacencyType) VALUES
(1, 2, 'moveable wall'),
(3, 4, 'door'),
(5, 6, 'separate'),
(1, 7, 'private access door'),
(2, 5, 'moveable wall');

INSERT INTO customer (customerId, firstName, lastName, email) VALUES
(121, 'Katy', 'Smith', 'Katy.Smith@email.com'),
(122, 'John', 'Wilson', 'John@email.com'),
(123, 'Mary', 'White', 'Mary.W@email.com'),
(124, 'Joseph', 'Harris', 'J.Harris@email.com');

INSERT INTO organization (organizationId, organizationName, email) VALUES
(1, 'Eventcorp', 'events@eventcorp.com'),
(2, 'Nyualum', 'alumni@nyu.edu'),
(3, 'Googletravel', 'travel@google.com'),
(4, 'Marriottgroup', 'meetings@marriott.com');

INSERT INTO customer_organization (customerId, organizationId) VALUES
(121, 2),
(122, 1),
(123, 3),
(124, 4);

INSERT INTO reservation (reservationId, customerId, reservationDate, depositRequired, specialRequest, status) VALUES
(101, 121, '2025-12-03', 0, 'Forest view', 'Confirmed'),
(102, 122, '2025-11-12', 1, 'Meeting Rooms', 'Checked-In'),
(103, 123, '2025-05-04', 0, 'Ocean view', 'Confirmed'),
(104, 124, '2025-10-16', 1, 'Forest Room', 'Confirmed');

INSERT INTO stay (stayId, reservationId, customerId, checkinTime, checkoutTime, numberOfGuest) VALUES
(202, 101, 121, '2026-02-27 13:20', '2026-02-28 11:00', 1),
(203, 102, 122, '2026-02-27 12:11', '2026-02-28 11:00', 5),
(204, 103, 123, '2026-02-28 15:22', '2026-03-01 11:00', 1),
(205, 104, 124, '2026-02-28 13:25', '2026-03-01 11:00', 1);

INSERT INTO room_assignment (stayId, roomId, date) VALUES
(202, 1, '2026-02-27'),
(203, 2, '2026-02-28'),
(204, 3, '2026-03-01'),
(205, 4, '2026-03-01');

INSERT INTO billing_arrangement (billingId, stayId, customerId, billingType, splitPercent) VALUES
(100, 202, 121, 'Room', 100.00),
(101, 203, 122, 'Incidentals', 50.00),
(102, 204, 123, 'Room', 50.00),
(103, 205, 124, 'Incidentals', 100.00);

INSERT INTO service (serviceId, serviceName, serviceType, defaultRate) VALUES
(1, 'Room Overnight', 'Internal', 400.00),
(2, 'Bar Charge', 'Internal', 0.00),
(3, 'Restaurant Charge', 'Internal', 0.00),
(4, 'Airport Shuttle', 'External', 40.00),
(5, 'Meeting Room Rental (per hour)', 'Internal', 100.00);

INSERT INTO transaction_info (transactionId, billingId, serviceId, date, time, finalAmount, authorizationStatus) VALUES
(201, 100, 1, '2026-02-28', '15:00', 200.00, 'Posted'),
(202, 100, 2, '2026-02-28', '20:00', 24.50, 'Posted'),
(203, 101, 1, '2026-02-28', '15:00', 200.00, 'Posted'),
(204, 102, 1, '2026-02-28', '15:00', 200.00, 'Posted'),
(205, 103, 1, '2026-02-28', '15:00', 200.00, 'Posted'),
(206, 102, 3, '2026-02-28', '19:30', 78.50, 'Authorized'),
(207, 102, 4, '2026-02-28', '07:30', 40.00, 'Posted'),
(208, 103, 5, '2026-02-28', '10:00', 100.00, 'Authorized');

INSERT INTO event (eventId, duration, estimatedAttendance, eventName) VALUES
(100, '2 hours', 100, 'art forum'),
(101, '4 hours', 60, 'math forum'),
(102, '3 hours', 90, 'lunch'),
(103, '2 hours', 100, 'meeting'),
(104, '5 hours', 120, 'breakfast');

INSERT INTO event_room_assignment (eventId, roomId, duration, usage, charge) VALUES
(100, 1, '2 hours', 'meeting', 100.00),
(101, 2, '4 hours', 'meeting', 120.00),
(102, 3, '3 hours', 'lunch', 300.00),
(103, 4, '2 hours', 'meeting', 150.00),
(104, 5, '5 hours', 'breakfast', 200.00);

INSERT INTO access_log (accessLogId, eventId, roomId, customerId, billingId, duration, estimatedAttendance, eventName) VALUES
(1, 100, 1, 121, 100, '2 hours', 100, 'art forum'),
(2, 101, 2, 122, 101, '4 hours', 60, 'math forum'),
(3, 102, 3, 123, 102, '3 hours', 90, 'lunch'),
(4, 103, 4, 124, 103, '2 hours', 100, 'meeting'),
(5, 104, 5, 124, 103, '5 hours', 120, 'breakfast');

INSERT INTO customer_location (locationId, customerId, facility, checkInTime, checkOutTime) VALUES
(1, 122, 'Gym', '12:30', '16:30'),
(2, 123, 'Outdoor Pool', '15:30', '17:30'),
(3, 124, 'Indoor Pool', '19:20', '19:40');

INSERT INTO employee (employeeId, deptId, firstName, lastName, position, shift) VALUES
(326, 10, 'James', 'Brown', 'Front Desk Manager', 'day'),
(327, 11, 'Lisa', 'Jay', 'Event coordinator', 'day'),
(328, 12, 'Michael', 'Garcia', 'Housekeeper', 'day');

INSERT INTO message (messageId, senderName, senderCustomerId, messageContext, timeRecorded, status, confidential) VALUES
(400, 'Katy Smith', 121, 'Late Check Out', '2026-02-28 13:25', 'Read', 0),
(401, 'John Wilson', 122, 'Event Arrangement', '2026-02-28 14:56', 'Read', 0),
(402, 'Front Desk', NULL, 'Package Delivery', '2026-02-28 15:25', 'Delivered', 0),
(403, 'Unknown Caller', NULL, 'Contact Main Office Urgently', '2026-02-28 16:00', 'New', 1);
