PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS message;
DROP TABLE IF EXISTS employee;
DROP TABLE IF EXISTS customer_location;
DROP TABLE IF EXISTS access_log;
DROP TABLE IF EXISTS event_room_assignment;
DROP TABLE IF EXISTS event;
DROP TABLE IF EXISTS transaction_info;
DROP TABLE IF EXISTS service;
DROP TABLE IF EXISTS billing_arrangement;
DROP TABLE IF EXISTS room_assignment;
DROP TABLE IF EXISTS stay;
DROP TABLE IF EXISTS reservation;
DROP TABLE IF EXISTS customer_organization;
DROP TABLE IF EXISTS organization;
DROP TABLE IF EXISTS customer;
DROP TABLE IF EXISTS room_adjacency;
DROP TABLE IF EXISTS room_feature_assignment;
DROP TABLE IF EXISTS feature;
DROP TABLE IF EXISTS room;
DROP TABLE IF EXISTS wing;
DROP TABLE IF EXISTS building;
DROP TABLE IF EXISTS hotel_complex;

CREATE TABLE hotel_complex (
    hotelComplexId INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    address TEXT NOT NULL
);

CREATE TABLE building (
    buildingId INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    hotelComplexId INTEGER NOT NULL,
    FOREIGN KEY (hotelComplexId) REFERENCES hotel_complex(hotelComplexId)
);

CREATE TABLE wing (
    wingId INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    buildingId INTEGER NOT NULL,
    proximityFeatures TEXT,
    handicappedAccess INTEGER NOT NULL,
    smokingPolicy TEXT NOT NULL,
    FOREIGN KEY (buildingId) REFERENCES building(buildingId)
);

CREATE TABLE room (
    roomId INTEGER PRIMARY KEY,
    wingId INTEGER NOT NULL,
    number INTEGER NOT NULL,
    floor INTEGER NOT NULL,
    type TEXT NOT NULL,
    maxOccupancy INTEGER NOT NULL,
    baseRate DECIMAL(10,2) NOT NULL,
    smokingPolicy TEXT NOT NULL,
    hasToilet INTEGER NOT NULL,
    status TEXT NOT NULL,
    FOREIGN KEY (wingId) REFERENCES wing(wingId)
);

CREATE TABLE feature (
    featureId INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    value TEXT NOT NULL
);

CREATE TABLE room_feature_assignment (
    roomId INTEGER NOT NULL,
    featureId INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    PRIMARY KEY (roomId, featureId),
    FOREIGN KEY (roomId) REFERENCES room(roomId),
    FOREIGN KEY (featureId) REFERENCES feature(featureId)
);

CREATE TABLE room_adjacency (
    roomId1 INTEGER NOT NULL,
    roomId2 INTEGER NOT NULL,
    adjacencyType TEXT NOT NULL,
    PRIMARY KEY (roomId1, roomId2),
    FOREIGN KEY (roomId1) REFERENCES room(roomId),
    FOREIGN KEY (roomId2) REFERENCES room(roomId)
);

CREATE TABLE customer (
    customerId INTEGER PRIMARY KEY,
    firstName TEXT NOT NULL,
    lastName TEXT NOT NULL,
    email TEXT NOT NULL
);

CREATE TABLE organization (
    organizationId INTEGER PRIMARY KEY,
    organizationName TEXT NOT NULL,
    email TEXT NOT NULL
);

CREATE TABLE customer_organization (
    customerId INTEGER NOT NULL,
    organizationId INTEGER NOT NULL,
    PRIMARY KEY (customerId, organizationId),
    FOREIGN KEY (customerId) REFERENCES customer(customerId),
    FOREIGN KEY (organizationId) REFERENCES organization(organizationId)
);

CREATE TABLE reservation (
    reservationId INTEGER PRIMARY KEY,
    customerId INTEGER NOT NULL,
    reservationDate DATE NOT NULL,
    depositRequired INTEGER NOT NULL,
    specialRequest TEXT,
    status TEXT NOT NULL,
    FOREIGN KEY (customerId) REFERENCES customer(customerId)
);

CREATE TABLE stay (
    stayId INTEGER PRIMARY KEY,
    reservationId INTEGER NOT NULL,
    customerId INTEGER NOT NULL,
    checkinTime TEXT NOT NULL,
    checkoutTime TEXT NOT NULL,
    numberOfGuest INTEGER NOT NULL,
    FOREIGN KEY (reservationId) REFERENCES reservation(reservationId),
    FOREIGN KEY (customerId) REFERENCES customer(customerId)
);

CREATE TABLE room_assignment (
    stayId INTEGER NOT NULL,
    roomId INTEGER NOT NULL,
    date DATE NOT NULL,
    PRIMARY KEY (stayId, roomId, date),
    FOREIGN KEY (stayId) REFERENCES stay(stayId),
    FOREIGN KEY (roomId) REFERENCES room(roomId)
);

CREATE TABLE billing_arrangement (
    billingId INTEGER PRIMARY KEY,
    stayId INTEGER NOT NULL,
    customerId INTEGER NOT NULL,
    billingType TEXT NOT NULL,
    splitPercent DECIMAL(5,2) NOT NULL,
    FOREIGN KEY (stayId) REFERENCES stay(stayId),
    FOREIGN KEY (customerId) REFERENCES customer(customerId)
);

CREATE TABLE service (
    serviceId INTEGER PRIMARY KEY,
    serviceName TEXT NOT NULL,
    serviceType TEXT NOT NULL,
    defaultRate DECIMAL(10,2) NOT NULL
);

CREATE TABLE transaction_info (
    transactionId INTEGER PRIMARY KEY,
    billingId INTEGER NOT NULL,
    serviceId INTEGER,
    date DATE NOT NULL,
    time TEXT NOT NULL,
    finalAmount DECIMAL(10,2) NOT NULL,
    authorizationStatus TEXT NOT NULL,
    FOREIGN KEY (billingId) REFERENCES billing_arrangement(billingId),
    FOREIGN KEY (serviceId) REFERENCES service(serviceId)
);

CREATE TABLE event (
    eventId INTEGER PRIMARY KEY,
    duration TEXT NOT NULL,
    estimatedAttendance INTEGER,
    eventName TEXT NOT NULL
);

CREATE TABLE event_room_assignment (
    eventId INTEGER NOT NULL,
    roomId INTEGER NOT NULL,
    duration TEXT NOT NULL,
    usage TEXT NOT NULL,
    charge DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (eventId, roomId),
    FOREIGN KEY (eventId) REFERENCES event(eventId),
    FOREIGN KEY (roomId) REFERENCES room(roomId)
);

CREATE TABLE access_log (
    accessLogId INTEGER PRIMARY KEY,
    eventId INTEGER,
    roomId INTEGER NOT NULL,
    customerId INTEGER NOT NULL,
    billingId INTEGER,
    duration TEXT NOT NULL,
    estimatedAttendance INTEGER,
    eventName TEXT NOT NULL,
    FOREIGN KEY (eventId) REFERENCES event(eventId),
    FOREIGN KEY (roomId) REFERENCES room(roomId),
    FOREIGN KEY (customerId) REFERENCES customer(customerId),
    FOREIGN KEY (billingId) REFERENCES billing_arrangement(billingId)
);

CREATE TABLE customer_location (
    locationId INTEGER PRIMARY KEY,
    customerId INTEGER NOT NULL,
    facility TEXT NOT NULL,
    checkInTime TEXT NOT NULL,
    checkOutTime TEXT NOT NULL,
    FOREIGN KEY (customerId) REFERENCES customer(customerId)
);

CREATE TABLE employee (
    employeeId INTEGER PRIMARY KEY,
    deptId INTEGER NOT NULL,
    firstName TEXT NOT NULL,
    lastName TEXT NOT NULL,
    position TEXT NOT NULL,
    shift TEXT NOT NULL
);

CREATE TABLE message (
    messageId INTEGER PRIMARY KEY,
    senderName TEXT NOT NULL,
    senderCustomerId INTEGER,
    messageContext TEXT NOT NULL,
    timeRecorded TEXT NOT NULL,
    status TEXT NOT NULL,
    confidential INTEGER NOT NULL,
    FOREIGN KEY (senderCustomerId) REFERENCES customer(customerId)
);
